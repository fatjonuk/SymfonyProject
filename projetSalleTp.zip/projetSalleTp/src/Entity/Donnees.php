<?php

namespace SalleTpBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Donnees
 *
 * @ORM\Table(name="donnees", uniqueConstraints={@ORM\UniqueConstraint(name="id_dossier", columns={"id_dossier"})})
 * @ORM\Entity
 */
class Donnees
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id_dossier", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idDossier;

    /**
     * @var integer
     *
     * @ORM\Column(name="accession_number", type="integer", nullable=false)
     */
    private $accessionNumber;

    /**
     * @var integer
     *
     * @ORM\Column(name="code_cabinet", type="integer", nullable=false)
     */
    private $codeCabinet;

    /**
     * @var string
     *
     * @ORM\Column(name="libelle_cabinet", type="text", length=65535, nullable=false)
     */
    private $libelleCabinet;

    /**
     * @var integer
     *
     * @ORM\Column(name="dateDossier", type="integer", nullable=false)
     */
    private $datedossier;

    /**
     * @var integer
     *
     * @ORM\Column(name="anneeDossier", type="integer", nullable=false)
     */
    private $anneedossier;

    /**
     * @var integer
     *
     * @ORM\Column(name="moisDossier", type="text", nullable=false)
     */
    private $moisdossier;

    /**
     * @var integer
     *
     * @ORM\Column(name="num�roDuJourDossier", type="integer", nullable=false)
     */
    private $num�rodujourdossier;

    /**
     * @var string
     *
     * @ORM\Column(name="nomJourDossier", type="text", length=65535, nullable=false)
     */
    private $nomjourdossier;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="heureDossier", type="time", nullable=false)
     */
    private $heuredossier;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="heureCotation", type="time", nullable=false)
     */
    private $heurecotation;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="heureDebutExamen", type="time", nullable=false)
     */
    private $heuredebutexamen;

    /**
     * @var string
     *
     * @ORM\Column(name="heureFinExamen", type="text", length=65535, nullable=false)
     */
    private $heurefinexamen;

    /**
     * @var integer
     *
     * @ORM\Column(name="Patient", type="integer", nullable=false)
     */
    private $patient;

    /**
     * @var string
     *
     * @ORM\Column(name="nom_patient", type="text", length=65535, nullable=false)
     */
    private $nomPatient;

    /**
     * @var string
     *
     * @ORM\Column(name="prenom_patient", type="text", length=65535, nullable=false)
     */
    private $prenomPatient;

    /**
     * @var string
     *
     * @ORM\Column(name="nom_naiss_patient", type="text", length=65535, nullable=false)
     */
    private $nomNaissPatient;

    /**
     * @var integer
     *
     * @ORM\Column(name="DateDeNaissance", type="integer", nullable=false)
     */
    private $datedenaissance;

    /**
     * @var integer
     *
     * @ORM\Column(name="Ann�eDeNaissance", type="integer", nullable=false)
     */
    private $ann�edenaissance;

    /**
     * @var integer
     *
     * @ORM\Column(name="NIR", type="integer", nullable=false)
     */
    private $nir;

    /**
     * @var integer
     *
     * @ORM\Column(name="AgeALaDateDuDossier", type="integer", nullable=false)
     */
    private $agealadatedudossier;

    /**
     * @var string
     *
     * @ORM\Column(name="sexe", type="text", length=65535, nullable=false)
     */
    private $sexe;

    /**
     * @var string
     *
     * @ORM\Column(name="sexeARS", type="text", length=65535, nullable=false)
     */
    private $sexears;

    /**
     * @var integer
     *
     * @ORM\Column(name="code_postal", type="integer", nullable=false)
     */
    private $codePostal;

    /**
     * @var string
     *
     * @ORM\Column(name="ville", type="text", length=65535, nullable=false)
     */
    private $ville;

    /**
     * @var string
     *
     * @ORM\Column(name="Radiologue", type="text", length=65535, nullable=false)
     */
    private $radiologue;

    /**
     * @var string
     *
     * @ORM\Column(name="Actes", type="text", length=65535, nullable=false)
     */
    private $actes;

    /**
     * @var integer
     *
     * @ORM\Column(name="code_type_examen", type="integer", nullable=false)
     */
    private $codeTypeExamen;

    /**
     * @var string
     *
     * @ORM\Column(name="libelle_type_examen", type="text", length=65535, nullable=false)
     */
    private $libelleTypeExamen;

    /**
     * @var string
     *
     * @ORM\Column(name="modificateurs", type="text", length=65535, nullable=false)
     */
    private $modificateurs;

    /**
     * @var integer
     *
     * @ORM\Column(name="code_asso", type="integer", nullable=false)
     */
    private $codeAsso;

    /**
     * @var string
     *
     * @ORM\Column(name="Manipulateurs", type="text", length=65535, nullable=false)
     */
    private $manipulateurs;

    /**
     * @var integer
     *
     * @ORM\Column(name="appareil_code", type="integer", nullable=false)
     */
    private $appareilCode;

    /**
     * @var string
     *
     * @ORM\Column(name="appareil_libelle", type="text", length=65535, nullable=false)
     */
    private $appareilLibelle;

    /**
     * @var integer
     *
     * @ORM\Column(name="id_ident_amo", type="integer", nullable=false)
     */
    private $idIdentAmo;

    /**
     * @var integer
     *
     * @ORM\Column(name="codeAMO", type="integer", nullable=false)
     */
    private $codeamo;

    /**
     * @var integer
     *
     * @ORM\Column(name="id_ident_ets", type="integer", nullable=false)
     */
    private $idIdentEts;

    /**
     * @var integer
     *
     * @ORM\Column(name="id_ets", type="integer", nullable=false)
     */
    private $idEts;

    /**
     * @var integer
     *
     * @ORM\Column(name="ETS", type="integer", nullable=false)
     */
    private $ets;

    /**
     * @var integer
     *
     * @ORM\Column(name="num_sejour", type="integer", nullable=false)
     */
    private $numSejour;

    /**
     * @var integer
     *
     * @ORM\Column(name="nipp", type="integer", nullable=false)
     */
    private $nipp;

    /**
     * @var integer
     *
     * @ORM\Column(name="UF", type="integer", nullable=false)
     */
    private $uf;

    /**
     * @var string
     *
     * @ORM\Column(name="statut", type="text", length=65535, nullable=false)
     */
    private $statut;

    /**
     * @var string
     *
     * @ORM\Column(name="StatutDHospitalisation", type="text", length=65535, nullable=false)
     */
    private $statutdhospitalisation;

    /**
     * @var string
     *
     * @ORM\Column(name="activite_liberale", type="text", length=65535, nullable=false)
     */
    private $activiteLiberale;

    /**
     * @var string
     *
     * @ORM\Column(name="type_consultation", type="text", length=65535, nullable=false)
     */
    private $typeConsultation;

    /**
     * @var string
     *
     * @ORM\Column(name="type_accueil", type="text", length=65535, nullable=false)
     */
    private $typeAccueil;

    /**
     * @var integer
     *
     * @ORM\Column(name="NbActesAmbulatoiresPublics", type="integer", nullable=false)
     */
    private $nbactesambulatoirespublics;

    /**
     * @var integer
     *
     * @ORM\Column(name="NbActesAmbulatoiresActivit�Lib�rale", type="integer", nullable=false)
     */
    private $nbactesambulatoiresactivit�lib�rale;

    /**
     * @var integer
     *
     * @ORM\Column(name="NbActesEnHospitalisation", type="integer", nullable=false)
     */
    private $nbactesenhospitalisation;

    /**
     * @var integer
     *
     * @ORM\Column(name="NbActes", type="integer", nullable=false)
     */
    private $nbactes;

    /**
     * @var integer
     *
     * @ORM\Column(name="nb_produit", type="integer", nullable=false)
     */
    private $nbProduit;

    /**
     * @var string
     *
     * @ORM\Column(name="liste_produit", type="text", length=65535, nullable=false)
     */
    private $listeProduit;

    /**
     * @var integer
     *
     * @ORM\Column(name="cr_valide", type="integer", nullable=false)
     */
    private $crValide;

    /**
     * @var string
     *
     * @ORM\Column(name="cotation_valide", type="text", length=65535, nullable=false)
     */
    private $cotationValide;

    /**
     * @var string
     *
     * @ORM\Column(name="facture_valide", type="text", length=65535, nullable=false)
     */
    private $factureValide;

    /**
     * @var string
     *
     * @ORM\Column(name="facture_FT_valide", type="text", length=65535, nullable=false)
     */
    private $factureFtValide;

    /**
     * @var string
     *
     * @ORM\Column(name="m�decinPrescripteur", type="text", length=65535, nullable=false)
     */
    private $m�decinprescripteur;

    /**
     * @var string
     *
     * @ORM\Column(name="sp�cialit�M�decinPrescripteur", type="text", length=65535, nullable=false)
     */
    private $sp�cialit�m�decinprescripteur;

    /**
     * @var string
     *
     * @ORM\Column(name="m�decinTraitant", type="text", length=65535, nullable=false)
     */
    private $m�decintraitant;

    /**
     * @var integer
     *
     * @ORM\Column(name="sp�cialit�M�decinTraitant", type="integer", nullable=false)
     */
    private $sp�cialit�m�decintraitant;



    /**
     * Get idDossier
     *
     * @return integer
     */
    public function getIdDossier()
    {
        return $this->idDossier;
    }

    /**
     * Set accessionNumber
     *
     * @param integer $accessionNumber
     *
     * @return Donn�es
     */
    public function setAccessionNumber($accessionNumber)
    {
        $this->accessionNumber = $accessionNumber;

        return $this;
    }

    /**
     * Get accessionNumber
     *
     * @return integer
     */
    public function getAccessionNumber()
    {
        return $this->accessionNumber;
    }

    /**
     * Set codeCabinet
     *
     * @param integer $codeCabinet
     *
     * @return Donn�es
     */
    public function setCodeCabinet($codeCabinet)
    {
        $this->codeCabinet = $codeCabinet;

        return $this;
    }

    /**
     * Get codeCabinet
     *
     * @return integer
     */
    public function getCodeCabinet()
    {
        return $this->codeCabinet;
    }

    /**
     * Set libelleCabinet
     *
     * @param string $libelleCabinet
     *
     * @return Donn�es
     */
    public function setLibelleCabinet($libelleCabinet)
    {
        $this->libelleCabinet = $libelleCabinet;

        return $this;
    }

    /**
     * Get libelleCabinet
     *
     * @return string
     */
    public function getLibelleCabinet()
    {
        return $this->libelleCabinet;
    }

    /**
     * Set datedossier
     *
     * @param integer $datedossier
     *
     * @return Donn�es
     */
    public function setDatedossier($datedossier)
    {
        $this->datedossier = $datedossier;

        return $this;
    }

    /**
     * Get datedossier
     *
     * @return integer
     */
    public function getDatedossier()
    {
        return $this->datedossier;
    }

    /**
     * Set anneedossier
     *
     * @param integer $anneedossier
     *
     * @return Donn�es
     */
    public function setAnneedossier($anneedossier)
    {
        $this->anneedossier = $anneedossier;

        return $this;
    }

    /**
     * Get anneedossier
     *
     * @return integer
     */
    public function getAnneedossier()
    {
        return $this->anneedossier;
    }

    /**
     * Set moisdossier
     *
     * @param integer $moisdossier
     *
     * @return Donn�es
     */
    public function setMoisdossier($moisdossier)
    {
        $this->moisdossier = $moisdossier;

        return $this;
    }

    /**
     * Get moisdossier
     *
     * @return integer
     */
    public function getMoisdossier()
    {
        return $this->moisdossier;
    }

    /**
     * Set num�rodujourdossier
     *
     * @param integer $num�rodujourdossier
     *
     * @return Donn�es
     */
    public function setNum�rodujourdossier($num�rodujourdossier)
    {
        $this->num�rodujourdossier = $num�rodujourdossier;

        return $this;
    }

    /**
     * Get num�rodujourdossier
     *
     * @return integer
     */
    public function getNum�rodujourdossier()
    {
        return $this->num�rodujourdossier;
    }

    /**
     * Set nomjourdossier
     *
     * @param string $nomjourdossier
     *
     * @return Donn�es
     */
    public function setNomjourdossier($nomjourdossier)
    {
        $this->nomjourdossier = $nomjourdossier;

        return $this;
    }

    /**
     * Get nomjourdossier
     *
     * @return string
     */
    public function getNomjourdossier()
    {
        return $this->nomjourdossier;
    }

    /**
     * Set heuredossier
     *
     * @param \DateTime $heuredossier
     *
     * @return Donn�es
     */
    public function setHeuredossier($heuredossier)
    {
        $this->heuredossier = $heuredossier;

        return $this;
    }

    /**
     * Get heuredossier
     *
     * @return \DateTime
     */
    public function getHeuredossier()
    {
        return $this->heuredossier;
    }

    /**
     * Set heurecotation
     *
     * @param \DateTime $heurecotation
     *
     * @return Donn�es
     */
    public function setHeurecotation($heurecotation)
    {
        $this->heurecotation = $heurecotation;

        return $this;
    }

    /**
     * Get heurecotation
     *
     * @return \DateTime
     */
    public function getHeurecotation()
    {
        return $this->heurecotation;
    }

    /**
     * Set heuredebutexamen
     *
     * @param \DateTime $heuredebutexamen
     *
     * @return Donn�es
     */
    public function setHeuredebutexamen($heuredebutexamen)
    {
        $this->heuredebutexamen = $heuredebutexamen;

        return $this;
    }

    /**
     * Get heuredebutexamen
     *
     * @return \DateTime
     */
    public function getHeuredebutexamen()
    {
        return $this->heuredebutexamen;
    }

    /**
     * Set heurefinexamen
     *
     * @param string $heurefinexamen
     *
     * @return Donn�es
     */
    public function setHeurefinexamen($heurefinexamen)
    {
        $this->heurefinexamen = $heurefinexamen;

        return $this;
    }

    /**
     * Get heurefinexamen
     *
     * @return string
     */
    public function getHeurefinexamen()
    {
        return $this->heurefinexamen;
    }

    /**
     * Set patient
     *
     * @param integer $patient
     *
     * @return Donn�es
     */
    public function setPatient($patient)
    {
        $this->patient = $patient;

        return $this;
    }

    /**
     * Get patient
     *
     * @return integer
     */
    public function getPatient()
    {
        return $this->patient;
    }

    /**
     * Set nomPatient
     *
     * @param string $nomPatient
     *
     * @return Donn�es
     */
    public function setNomPatient($nomPatient)
    {
        $this->nomPatient = $nomPatient;

        return $this;
    }

    /**
     * Get nomPatient
     *
     * @return string
     */
    public function getNomPatient()
    {
        return $this->nomPatient;
    }

    /**
     * Set prenomPatient
     *
     * @param string $prenomPatient
     *
     * @return Donn�es
     */
    public function setPrenomPatient($prenomPatient)
    {
        $this->prenomPatient = $prenomPatient;

        return $this;
    }

    /**
     * Get prenomPatient
     *
     * @return string
     */
    public function getPrenomPatient()
    {
        return $this->prenomPatient;
    }

    /**
     * Set nomNaissPatient
     *
     * @param string $nomNaissPatient
     *
     * @return Donn�es
     */
    public function setNomNaissPatient($nomNaissPatient)
    {
        $this->nomNaissPatient = $nomNaissPatient;

        return $this;
    }

    /**
     * Get nomNaissPatient
     *
     * @return string
     */
    public function getNomNaissPatient()
    {
        return $this->nomNaissPatient;
    }

    /**
     * Set datedenaissance
     *
     * @param integer $datedenaissance
     *
     * @return Donn�es
     */
    public function setDatedenaissance($datedenaissance)
    {
        $this->datedenaissance = $datedenaissance;

        return $this;
    }

    /**
     * Get datedenaissance
     *
     * @return integer
     */
    public function getDatedenaissance()
    {
        return $this->datedenaissance;
    }

    /**
     * Set ann�edenaissance
     *
     * @param integer $ann�edenaissance
     *
     * @return Donn�es
     */
    public function setAnn�edenaissance($ann�edenaissance)
    {
        $this->ann�edenaissance = $ann�edenaissance;

        return $this;
    }

    /**
     * Get ann�edenaissance
     *
     * @return integer
     */
    public function getAnn�edenaissance()
    {
        return $this->ann�edenaissance;
    }

    /**
     * Set nir
     *
     * @param integer $nir
     *
     * @return Donn�es
     */
    public function setNir($nir)
    {
        $this->nir = $nir;

        return $this;
    }

    /**
     * Get nir
     *
     * @return integer
     */
    public function getNir()
    {
        return $this->nir;
    }

    /**
     * Set agealadatedudossier
     *
     * @param integer $agealadatedudossier
     *
     * @return Donn�es
     */
    public function setAgealadatedudossier($agealadatedudossier)
    {
        $this->agealadatedudossier = $agealadatedudossier;

        return $this;
    }

    /**
     * Get agealadatedudossier
     *
     * @return integer
     */
    public function getAgealadatedudossier()
    {
        return $this->agealadatedudossier;
    }

    /**
     * Set sexe
     *
     * @param string $sexe
     *
     * @return Donn�es
     */
    public function setSexe($sexe)
    {
        $this->sexe = $sexe;

        return $this;
    }

    /**
     * Get sexe
     *
     * @return string
     */
    public function getSexe()
    {
        return $this->sexe;
    }

    /**
     * Set sexears
     *
     * @param string $sexears
     *
     * @return Donn�es
     */
    public function setSexears($sexears)
    {
        $this->sexears = $sexears;

        return $this;
    }

    /**
     * Get sexears
     *
     * @return string
     */
    public function getSexears()
    {
        return $this->sexears;
    }

    /**
     * Set codePostal
     *
     * @param integer $codePostal
     *
     * @return Donn�es
     */
    public function setCodePostal($codePostal)
    {
        $this->codePostal = $codePostal;

        return $this;
    }

    /**
     * Get codePostal
     *
     * @return integer
     */
    public function getCodePostal()
    {
        return $this->codePostal;
    }

    /**
     * Set ville
     *
     * @param string $ville
     *
     * @return Donn�es
     */
    public function setVille($ville)
    {
        $this->ville = $ville;

        return $this;
    }

    /**
     * Get ville
     *
     * @return string
     */
    public function getVille()
    {
        return $this->ville;
    }

    /**
     * Set radiologue
     *
     * @param string $radiologue
     *
     * @return Donn�es
     */
    public function setRadiologue($radiologue)
    {
        $this->radiologue = $radiologue;

        return $this;
    }

    /**
     * Get radiologue
     *
     * @return string
     */
    public function getRadiologue()
    {
        return $this->radiologue;
    }

    /**
     * Set actes
     *
     * @param string $actes
     *
     * @return Donn�es
     */
    public function setActes($actes)
    {
        $this->actes = $actes;

        return $this;
    }

    /**
     * Get actes
     *
     * @return string
     */
    public function getActes()
    {
        return $this->actes;
    }

    /**
     * Set codeTypeExamen
     *
     * @param integer $codeTypeExamen
     *
     * @return Donn�es
     */
    public function setCodeTypeExamen($codeTypeExamen)
    {
        $this->codeTypeExamen = $codeTypeExamen;

        return $this;
    }

    /**
     * Get codeTypeExamen
     *
     * @return integer
     */
    public function getCodeTypeExamen()
    {
        return $this->codeTypeExamen;
    }

    /**
     * Set libelleTypeExamen
     *
     * @param string $libelleTypeExamen
     *
     * @return Donn�es
     */
    public function setLibelleTypeExamen($libelleTypeExamen)
    {
        $this->libelleTypeExamen = $libelleTypeExamen;

        return $this;
    }

    /**
     * Get libelleTypeExamen
     *
     * @return string
     */
    public function getLibelleTypeExamen()
    {
        return $this->libelleTypeExamen;
    }

    /**
     * Set modificateurs
     *
     * @param string $modificateurs
     *
     * @return Donn�es
     */
    public function setModificateurs($modificateurs)
    {
        $this->modificateurs = $modificateurs;

        return $this;
    }

    /**
     * Get modificateurs
     *
     * @return string
     */
    public function getModificateurs()
    {
        return $this->modificateurs;
    }

    /**
     * Set codeAsso
     *
     * @param integer $codeAsso
     *
     * @return Donn�es
     */
    public function setCodeAsso($codeAsso)
    {
        $this->codeAsso = $codeAsso;

        return $this;
    }

    /**
     * Get codeAsso
     *
     * @return integer
     */
    public function getCodeAsso()
    {
        return $this->codeAsso;
    }

    /**
     * Set manipulateurs
     *
     * @param string $manipulateurs
     *
     * @return Donn�es
     */
    public function setManipulateurs($manipulateurs)
    {
        $this->manipulateurs = $manipulateurs;

        return $this;
    }

    /**
     * Get manipulateurs
     *
     * @return string
     */
    public function getManipulateurs()
    {
        return $this->manipulateurs;
    }

    /**
     * Set appareilCode
     *
     * @param integer $appareilCode
     *
     * @return Donn�es
     */
    public function setAppareilCode($appareilCode)
    {
        $this->appareilCode = $appareilCode;

        return $this;
    }

    /**
     * Get appareilCode
     *
     * @return integer
     */
    public function getAppareilCode()
    {
        return $this->appareilCode;
    }

    /**
     * Set appareilLibelle
     *
     * @param string $appareilLibelle
     *
     * @return Donn�es
     */
    public function setAppareilLibelle($appareilLibelle)
    {
        $this->appareilLibelle = $appareilLibelle;

        return $this;
    }

    /**
     * Get appareilLibelle
     *
     * @return string
     */
    public function getAppareilLibelle()
    {
        return $this->appareilLibelle;
    }

    /**
     * Set idIdentAmo
     *
     * @param integer $idIdentAmo
     *
     * @return Donn�es
     */
    public function setIdIdentAmo($idIdentAmo)
    {
        $this->idIdentAmo = $idIdentAmo;

        return $this;
    }

    /**
     * Get idIdentAmo
     *
     * @return integer
     */
    public function getIdIdentAmo()
    {
        return $this->idIdentAmo;
    }

    /**
     * Set codeamo
     *
     * @param integer $codeamo
     *
     * @return Donn�es
     */
    public function setCodeamo($codeamo)
    {
        $this->codeamo = $codeamo;

        return $this;
    }

    /**
     * Get codeamo
     *
     * @return integer
     */
    public function getCodeamo()
    {
        return $this->codeamo;
    }

    /**
     * Set idIdentEts
     *
     * @param integer $idIdentEts
     *
     * @return Donn�es
     */
    public function setIdIdentEts($idIdentEts)
    {
        $this->idIdentEts = $idIdentEts;

        return $this;
    }

    /**
     * Get idIdentEts
     *
     * @return integer
     */
    public function getIdIdentEts()
    {
        return $this->idIdentEts;
    }

    /**
     * Set idEts
     *
     * @param integer $idEts
     *
     * @return Donn�es
     */
    public function setIdEts($idEts)
    {
        $this->idEts = $idEts;

        return $this;
    }

    /**
     * Get idEts
     *
     * @return integer
     */
    public function getIdEts()
    {
        return $this->idEts;
    }

    /**
     * Set ets
     *
     * @param integer $ets
     *
     * @return Donn�es
     */
    public function setEts($ets)
    {
        $this->ets = $ets;

        return $this;
    }

    /**
     * Get ets
     *
     * @return integer
     */
    public function getEts()
    {
        return $this->ets;
    }

    /**
     * Set numSejour
     *
     * @param integer $numSejour
     *
     * @return Donn�es
     */
    public function setNumSejour($numSejour)
    {
        $this->numSejour = $numSejour;

        return $this;
    }

    /**
     * Get numSejour
     *
     * @return integer
     */
    public function getNumSejour()
    {
        return $this->numSejour;
    }

    /**
     * Set nipp
     *
     * @param integer $nipp
     *
     * @return Donn�es
     */
    public function setNipp($nipp)
    {
        $this->nipp = $nipp;

        return $this;
    }

    /**
     * Get nipp
     *
     * @return integer
     */
    public function getNipp()
    {
        return $this->nipp;
    }

    /**
     * Set uf
     *
     * @param integer $uf
     *
     * @return Donn�es
     */
    public function setUf($uf)
    {
        $this->uf = $uf;

        return $this;
    }

    /**
     * Get uf
     *
     * @return integer
     */
    public function getUf()
    {
        return $this->uf;
    }

    /**
     * Set statut
     *
     * @param string $statut
     *
     * @return Donn�es
     */
    public function setStatut($statut)
    {
        $this->statut = $statut;

        return $this;
    }

    /**
     * Get statut
     *
     * @return string
     */
    public function getStatut()
    {
        return $this->statut;
    }

    /**
     * Set statutdhospitalisation
     *
     * @param string $statutdhospitalisation
     *
     * @return Donn�es
     */
    public function setStatutdhospitalisation($statutdhospitalisation)
    {
        $this->statutdhospitalisation = $statutdhospitalisation;

        return $this;
    }

    /**
     * Get statutdhospitalisation
     *
     * @return string
     */
    public function getStatutdhospitalisation()
    {
        return $this->statutdhospitalisation;
    }

    /**
     * Set activiteLiberale
     *
     * @param string $activiteLiberale
     *
     * @return Donn�es
     */
    public function setActiviteLiberale($activiteLiberale)
    {
        $this->activiteLiberale = $activiteLiberale;

        return $this;
    }

    /**
     * Get activiteLiberale
     *
     * @return string
     */
    public function getActiviteLiberale()
    {
        return $this->activiteLiberale;
    }

    /**
     * Set typeConsultation
     *
     * @param string $typeConsultation
     *
     * @return Donn�es
     */
    public function setTypeConsultation($typeConsultation)
    {
        $this->typeConsultation = $typeConsultation;

        return $this;
    }

    /**
     * Get typeConsultation
     *
     * @return string
     */
    public function getTypeConsultation()
    {
        return $this->typeConsultation;
    }

    /**
     * Set typeAccueil
     *
     * @param string $typeAccueil
     *
     * @return Donn�es
     */
    public function setTypeAccueil($typeAccueil)
    {
        $this->typeAccueil = $typeAccueil;

        return $this;
    }

    /**
     * Get typeAccueil
     *
     * @return string
     */
    public function getTypeAccueil()
    {
        return $this->typeAccueil;
    }

    /**
     * Set nbactesambulatoirespublics
     *
     * @param integer $nbactesambulatoirespublics
     *
     * @return Donn�es
     */
    public function setNbactesambulatoirespublics($nbactesambulatoirespublics)
    {
        $this->nbactesambulatoirespublics = $nbactesambulatoirespublics;

        return $this;
    }

    /**
     * Get nbactesambulatoirespublics
     *
     * @return integer
     */
    public function getNbactesambulatoirespublics()
    {
        return $this->nbactesambulatoirespublics;
    }

    /**
     * Set nbactesambulatoiresactivit�lib�rale
     *
     * @param integer $nbactesambulatoiresactivit�lib�rale
     *
     * @return Donn�es
     */
    public function setNbactesambulatoiresactivit�lib�rale($nbactesambulatoiresactivit�lib�rale)
    {
        $this->nbactesambulatoiresactivit�lib�rale = $nbactesambulatoiresactivit�lib�rale;

        return $this;
    }

    /**
     * Get nbactesambulatoiresactivit�lib�rale
     *
     * @return integer
     */
    public function getNbactesambulatoiresactivit�lib�rale()
    {
        return $this->nbactesambulatoiresactivit�lib�rale;
    }

    /**
     * Set nbactesenhospitalisation
     *
     * @param integer $nbactesenhospitalisation
     *
     * @return Donn�es
     */
    public function setNbactesenhospitalisation($nbactesenhospitalisation)
    {
        $this->nbactesenhospitalisation = $nbactesenhospitalisation;

        return $this;
    }

    /**
     * Get nbactesenhospitalisation
     *
     * @return integer
     */
    public function getNbactesenhospitalisation()
    {
        return $this->nbactesenhospitalisation;
    }

    /**
     * Set nbactes
     *
     * @param integer $nbactes
     *
     * @return Donn�es
     */
    public function setNbactes($nbactes)
    {
        $this->nbactes = $nbactes;

        return $this;
    }

    /**
     * Get nbactes
     *
     * @return integer
     */
    public function getNbactes()
    {
        return $this->nbactes;
    }

    /**
     * Set nbProduit
     *
     * @param integer $nbProduit
     *
     * @return Donn�es
     */
    public function setNbProduit($nbProduit)
    {
        $this->nbProduit = $nbProduit;

        return $this;
    }

    /**
     * Get nbProduit
     *
     * @return integer
     */
    public function getNbProduit()
    {
        return $this->nbProduit;
    }

    /**
     * Set listeProduit
     *
     * @param string $listeProduit
     *
     * @return Donn�es
     */
    public function setListeProduit($listeProduit)
    {
        $this->listeProduit = $listeProduit;

        return $this;
    }

    /**
     * Get listeProduit
     *
     * @return string
     */
    public function getListeProduit()
    {
        return $this->listeProduit;
    }

    /**
     * Set crValide
     *
     * @param integer $crValide
     *
     * @return Donn�es
     */
    public function setCrValide($crValide)
    {
        $this->crValide = $crValide;

        return $this;
    }

    /**
     * Get crValide
     *
     * @return integer
     */
    public function getCrValide()
    {
        return $this->crValide;
    }

    /**
     * Set cotationValide
     *
     * @param string $cotationValide
     *
     * @return Donn�es
     */
    public function setCotationValide($cotationValide)
    {
        $this->cotationValide = $cotationValide;

        return $this;
    }

    /**
     * Get cotationValide
     *
     * @return string
     */
    public function getCotationValide()
    {
        return $this->cotationValide;
    }

    /**
     * Set factureValide
     *
     * @param string $factureValide
     *
     * @return Donn�es
     */
    public function setFactureValide($factureValide)
    {
        $this->factureValide = $factureValide;

        return $this;
    }

    /**
     * Get factureValide
     *
     * @return string
     */
    public function getFactureValide()
    {
        return $this->factureValide;
    }

    /**
     * Set factureFtValide
     *
     * @param string $factureFtValide
     *
     * @return Donn�es
     */
    public function setFactureFtValide($factureFtValide)
    {
        $this->factureFtValide = $factureFtValide;

        return $this;
    }

    /**
     * Get factureFtValide
     *
     * @return string
     */
    public function getFactureFtValide()
    {
        return $this->factureFtValide;
    }

    /**
     * Set m�decinprescripteur
     *
     * @param string $m�decinprescripteur
     *
     * @return Donn�es
     */
    public function setM�decinprescripteur($m�decinprescripteur)
    {
        $this->m�decinprescripteur = $m�decinprescripteur;

        return $this;
    }

    /**
     * Get m�decinprescripteur
     *
     * @return string
     */
    public function getM�decinprescripteur()
    {
        return $this->m�decinprescripteur;
    }

    /**
     * Set sp�cialit�m�decinprescripteur
     *
     * @param string $sp�cialit�m�decinprescripteur
     *
     * @return Donn�es
     */
    public function setSp�cialit�m�decinprescripteur($sp�cialit�m�decinprescripteur)
    {
        $this->sp�cialit�m�decinprescripteur = $sp�cialit�m�decinprescripteur;

        return $this;
    }

    /**
     * Get sp�cialit�m�decinprescripteur
     *
     * @return string
     */
    public function getSp�cialit�m�decinprescripteur()
    {
        return $this->sp�cialit�m�decinprescripteur;
    }

    /**
     * Set m�decintraitant
     *
     * @param string $m�decintraitant
     *
     * @return Donn�es
     */
    public function setM�decintraitant($m�decintraitant)
    {
        $this->m�decintraitant = $m�decintraitant;

        return $this;
    }

    /**
     * Get m�decintraitant
     *
     * @return string
     */
    public function getM�decintraitant()
    {
        return $this->m�decintraitant;
    }

    /**
     * Set sp�cialit�m�decintraitant
     *
     * @param integer $sp�cialit�m�decintraitant
     *
     * @return Donn�es
     */
    public function setSp�cialit�m�decintraitant($sp�cialit�m�decintraitant)
    {
        $this->sp�cialit�m�decintraitant = $sp�cialit�m�decintraitant;

        return $this;
    }

    /**
     * Get sp�cialit�m�decintraitant
     *
     * @return integer
     */
    public function getSp�cialit�m�decintraitant()
    {
        return $this->sp�cialit�m�decintraitant;
    }
}
